﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eShopping.Core.Entities
{
    public class CatalogImage:BaseEntity
    {
        public string ImageURL { get; set; }
        public CatalogImage(string imageURL)
        {
            ImageURL = imageURL;
        }
    }
}
