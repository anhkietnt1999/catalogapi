﻿
namespace eShopping.Core.Entities
{
    public class CatalogType : BaseEntity
    {
        public string Type { get;  set; }
        public CatalogType(string type)
        {
            Type = type;
        }
    }
}
