﻿using eShopping.Core.Data;
using eShopping.Core.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eShopping.DataAccessLayer.Repositories
{
    public class GenericRepository<T> : IGenericRepository<T> where T : BaseEntity
    {
        private CatalogContext _context;
        private DbSet<T> table = null;
        public GenericRepository(CatalogContext context)
        {
            this._context = context;
        }
        public async Task DeleteAsync(object id)
        {
           T existing = table.Find(id);
            table.Remove(existing);
            await Task.CompletedTask;
        }

        public async Task<IEnumerable<T>> GetAllAsync()
        {
           var items = table.ToList();
           return await Task.FromResult(items);
        }

        public async Task<T> GetByIdAsync(object id)
        {
            var item =  table.Find(id);
            return await Task.FromResult(item);
        }

        public async Task InsertAsync(T obj)
        {
            table.Add(obj);
            await Task.CompletedTask;

        }

        public async Task Save()
        {
            _context.SaveChanges();
            await Task.CompletedTask;

        }

        public async Task UpdateAsync(T obj)
        {
             table.Attach(obj);
             _context.Entry(obj).State = EntityState.Modified;
            await Task.CompletedTask;
        }
    }
}
